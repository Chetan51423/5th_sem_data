package Array;
import java.util.*;
public class Proble_75
{
    public static void main(String [] args)
    {
        Scanner sc = new Scanner(System.in);
        int row = sc.nextInt();
        int col = sc.nextInt();

        int arr1[][]= new int[row][col];


        System.out.println("Enter the elements of 1st array");
        for(int i=0; i<row; i++)
        {
            for(int j=0; j<col; j++)
            {
                arr1[i][j]=sc.nextInt();
            }
        }
        int arr[] = row_wise(arr1);
        for(int p=0; p<row*col; p++)
        {
            System.out.println(arr[p]);
        }
    }
    public static int[] row_wise(int arr[][])
    {
        int r = arr.length;
        int c = arr[0].length;
        int a[] = new int[r*c];

        for(int i=0; i<r; i++)
        {
            if(i%2==0)
            {
                for(int j=0; j<c; j++)
                {
                    a[i]=arr[i][j];
                }
            }
            else
            {
                for(int j=c-1; j>=0; j--)
                {
                    a[i]=arr[i][j];
                }
            }

        }
        return a;
    }

}
