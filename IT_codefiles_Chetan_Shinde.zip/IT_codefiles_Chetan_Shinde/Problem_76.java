package Array;
import java.util.*;
public class Problem_76
{
    public static void main(String [] args)
    {
        Scanner sc = new Scanner(System.in);
        int row = sc.nextInt();
        int col = sc.nextInt();

        int arr1[][]= new int[row][col];


        System.out.println("Enter the elements of 1st array");
        for(int i=0; i<row; i++)
        {
            for(int j=0; j<col; j++)
            {
                arr1[i][j]=sc.nextInt();
            }
        }

        int arr[] = new int[row];
        for(int i=0; i<row; i++)
        {
            int sum=0;
            for(int j=0; j<col; j++)
            {
                sum= sum+arr1[i][j];
            }
            arr[i]= sum;
        }

        for(int i=0; i<row; i++)
        {
            System.out.println(arr[i]);
        }

    }
}
