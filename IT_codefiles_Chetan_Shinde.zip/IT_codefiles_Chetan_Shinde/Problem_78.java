package Array;
import java.util.*;
public class Problem_78
{
    public static void main(String [] args)
    {
        Scanner sc = new Scanner(System.in);
        int row = sc.nextInt();
        int col = sc.nextInt();

        int arr1[][]= new int[row][col];


        System.out.println("Enter the elements of 1st array");
        for(int i=0; i<row; i++)
        {
            for(int j=0; j<col; j++)
            {
                arr1[i][j]=sc.nextInt();
            }
        }
        int arr2[][]= new int[row][col];
        System.out.println("Enter the elements of 2st array");
        for(int i=0; i<row; i++)
        {
            for(int j=0; j<col; j++)
            {
                arr2[i][j]=sc.nextInt();
            }
        }

        int arr3[][]= new int[row][col];
        for(int i=0; i<row; i++)
        {
            for(int j=0; j<col; j++)
            {
                arr3[i][j]=arr1[i][j] + arr2[i][j];
            }
        }

        for(int i=0; i<row; i++)
        {
            for(int j=0; j<col; j++)
            {
                System.out.println(arr3[i][j]);
            }

        }


    }
}
