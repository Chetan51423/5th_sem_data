package Array;
import java.util.*;
public class Problem_73
{
   public static void main(String [] args)
   {
       Scanner sc = new Scanner(System.in);
       int row = sc.nextInt();
       int col = sc.nextInt();

       int arr1[][]= new int[row][col];
       int arr2[][]= new int[row][col];

       System.out.println("Enter the elements of 1st array");
       for(int i=0; i<row; i++)
       {
           for(int j=0; j<col; j++)
           {
               arr1[i][j]=sc.nextInt();
           }
       }
       System.out.println("Enter the elements of 2st array");
       for(int i=0; i<row; i++)
       {
           for(int j=0; j<col; j++)
           {
               arr2[i][j]=sc.nextInt();
           }
       }

   }
   public static int same(int a1[], int a2[], int r, int c)
   {
       //int r = arr1.length;
       //int c = arr1[].length;

       for(int i=0; i<r; i++)
       {
           for(int j=0; j<c; j++)
           {
               if(a1[i][j]== a2[i][j])
               {
                   return 0;
               }

           }
       }
       return 1;
   }
}
